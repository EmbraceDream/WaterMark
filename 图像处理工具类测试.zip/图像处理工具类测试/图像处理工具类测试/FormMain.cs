﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图像处理工具类测试
{
    public partial class FormMain : Form
    {
        public readonly string ImgExt = "*.jpg|*.png|*.bmp|*.jpeg";
        public FormMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var ft = new FormThumb(this);            
            ft.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           var fc = new FormCompress(this);
           fc.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var fr = new FormRotate(this);
            fr.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var fw = new FormWater(this);
            fw.Show();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            
        }      
    }
}
