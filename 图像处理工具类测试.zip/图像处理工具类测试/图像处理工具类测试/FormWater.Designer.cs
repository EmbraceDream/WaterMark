﻿namespace 图像处理工具类测试
{
    partial class FormWater
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtWaterText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtWaterImg = new System.Windows.Forms.TextBox();
            this.radio1 = new System.Windows.Forms.RadioButton();
            this.radio2 = new System.Windows.Forms.RadioButton();
            this.radio3 = new System.Windows.Forms.RadioButton();
            this.radio6 = new System.Windows.Forms.RadioButton();
            this.radio5 = new System.Windows.Forms.RadioButton();
            this.radio4 = new System.Windows.Forms.RadioButton();
            this.radio9 = new System.Windows.Forms.RadioButton();
            this.radio8 = new System.Windows.Forms.RadioButton();
            this.radio7 = new System.Windows.Forms.RadioButton();
            this.txtOpacity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAngle = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPadding = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtQuality = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "文字";
            // 
            // txtWaterText
            // 
            this.txtWaterText.Location = new System.Drawing.Point(53, 8);
            this.txtWaterText.Multiline = true;
            this.txtWaterText.Name = "txtWaterText";
            this.txtWaterText.Size = new System.Drawing.Size(207, 41);
            this.txtWaterText.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "位置";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "图片";
            // 
            // txtWaterImg
            // 
            this.txtWaterImg.Location = new System.Drawing.Point(54, 57);
            this.txtWaterImg.Name = "txtWaterImg";
            this.txtWaterImg.Size = new System.Drawing.Size(207, 21);
            this.txtWaterImg.TabIndex = 4;
            this.txtWaterImg.Text = "water.jpg";
            // 
            // radio1
            // 
            this.radio1.AutoSize = true;
            this.radio1.Location = new System.Drawing.Point(53, 93);
            this.radio1.Name = "radio1";
            this.radio1.Size = new System.Drawing.Size(47, 16);
            this.radio1.TabIndex = 5;
            this.radio1.Text = "左上";
            this.radio1.UseVisualStyleBackColor = true;
            this.radio1.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio2
            // 
            this.radio2.AutoSize = true;
            this.radio2.Location = new System.Drawing.Point(123, 93);
            this.radio2.Name = "radio2";
            this.radio2.Size = new System.Drawing.Size(47, 16);
            this.radio2.TabIndex = 6;
            this.radio2.Text = "中上";
            this.radio2.UseVisualStyleBackColor = true;
            this.radio2.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio3
            // 
            this.radio3.AutoSize = true;
            this.radio3.Location = new System.Drawing.Point(205, 93);
            this.radio3.Name = "radio3";
            this.radio3.Size = new System.Drawing.Size(47, 16);
            this.radio3.TabIndex = 7;
            this.radio3.Text = "右上";
            this.radio3.UseVisualStyleBackColor = true;
            this.radio3.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio6
            // 
            this.radio6.AutoSize = true;
            this.radio6.Location = new System.Drawing.Point(205, 117);
            this.radio6.Name = "radio6";
            this.radio6.Size = new System.Drawing.Size(47, 16);
            this.radio6.TabIndex = 10;
            this.radio6.Text = "右中";
            this.radio6.UseVisualStyleBackColor = true;
            this.radio6.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio5
            // 
            this.radio5.AutoSize = true;
            this.radio5.Checked = true;
            this.radio5.Location = new System.Drawing.Point(123, 117);
            this.radio5.Name = "radio5";
            this.radio5.Size = new System.Drawing.Size(47, 16);
            this.radio5.TabIndex = 9;
            this.radio5.TabStop = true;
            this.radio5.Text = "正中";
            this.radio5.UseVisualStyleBackColor = true;
            this.radio5.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio4
            // 
            this.radio4.AutoSize = true;
            this.radio4.Location = new System.Drawing.Point(53, 117);
            this.radio4.Name = "radio4";
            this.radio4.Size = new System.Drawing.Size(47, 16);
            this.radio4.TabIndex = 8;
            this.radio4.Text = "左中";
            this.radio4.UseVisualStyleBackColor = true;
            this.radio4.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio9
            // 
            this.radio9.AutoSize = true;
            this.radio9.Location = new System.Drawing.Point(205, 141);
            this.radio9.Name = "radio9";
            this.radio9.Size = new System.Drawing.Size(47, 16);
            this.radio9.TabIndex = 13;
            this.radio9.Text = "右下";
            this.radio9.UseVisualStyleBackColor = true;
            this.radio9.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio8
            // 
            this.radio8.AutoSize = true;
            this.radio8.Location = new System.Drawing.Point(123, 141);
            this.radio8.Name = "radio8";
            this.radio8.Size = new System.Drawing.Size(47, 16);
            this.radio8.TabIndex = 12;
            this.radio8.Text = "中下";
            this.radio8.UseVisualStyleBackColor = true;
            this.radio8.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // radio7
            // 
            this.radio7.AutoSize = true;
            this.radio7.Location = new System.Drawing.Point(53, 141);
            this.radio7.Name = "radio7";
            this.radio7.Size = new System.Drawing.Size(47, 16);
            this.radio7.TabIndex = 11;
            this.radio7.Text = "左下";
            this.radio7.UseVisualStyleBackColor = true;
            this.radio7.CheckedChanged += new System.EventHandler(this.radio1_CheckedChanged);
            // 
            // txtOpacity
            // 
            this.txtOpacity.Location = new System.Drawing.Point(58, 174);
            this.txtOpacity.Name = "txtOpacity";
            this.txtOpacity.Size = new System.Drawing.Size(195, 21);
            this.txtOpacity.TabIndex = 15;
            this.txtOpacity.Text = "60";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 14;
            this.label4.Text = "透明度";
            // 
            // txtAngle
            // 
            this.txtAngle.Location = new System.Drawing.Point(59, 253);
            this.txtAngle.Name = "txtAngle";
            this.txtAngle.Size = new System.Drawing.Size(60, 21);
            this.txtAngle.TabIndex = 17;
            this.txtAngle.Text = "135";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 16;
            this.label5.Text = "旋转角度";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(126, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 12);
            this.label6.TabIndex = 18;
            this.label6.Text = "只对图片水印有效";
            // 
            // txtPadding
            // 
            this.txtPadding.Location = new System.Drawing.Point(58, 213);
            this.txtPadding.Name = "txtPadding";
            this.txtPadding.Size = new System.Drawing.Size(60, 21);
            this.txtPadding.TabIndex = 20;
            this.txtPadding.Text = "30";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 217);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 19;
            this.label7.Text = "内边界";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(126, 217);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 12);
            this.label8.TabIndex = 21;
            this.label8.Text = "类似CSS里的padding";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.panel1);
            this.groupBox3.Location = new System.Drawing.Point(12, 331);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(255, 106);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "将图片拖进白色区域进行处理";
            // 
            // panel1
            // 
            this.panel1.AllowDrop = true;
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(7, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(242, 79);
            this.panel1.TabIndex = 0;
            this.panel1.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel1_DragDrop);
            this.panel1.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel1_DragEnter);
            // 
            // txtQuality
            // 
            this.txtQuality.Location = new System.Drawing.Point(59, 290);
            this.txtQuality.Name = "txtQuality";
            this.txtQuality.Size = new System.Drawing.Size(60, 21);
            this.txtQuality.TabIndex = 24;
            this.txtQuality.Text = "93";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 294);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 23;
            this.label9.Text = "质量";
            // 
            // FormWater
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 449);
            this.Controls.Add(this.txtQuality);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtPadding);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAngle);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtOpacity);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.radio9);
            this.Controls.Add(this.radio8);
            this.Controls.Add(this.radio7);
            this.Controls.Add(this.radio6);
            this.Controls.Add(this.radio5);
            this.Controls.Add(this.radio4);
            this.Controls.Add(this.radio3);
            this.Controls.Add(this.radio2);
            this.Controls.Add(this.radio1);
            this.Controls.Add(this.txtWaterImg);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtWaterText);
            this.Controls.Add(this.label1);
            this.Name = "FormWater";
            this.Text = "水印";
            this.Load += new System.EventHandler(this.FormWater_Load);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtWaterText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtWaterImg;
        private System.Windows.Forms.RadioButton radio1;
        private System.Windows.Forms.RadioButton radio2;
        private System.Windows.Forms.RadioButton radio3;
        private System.Windows.Forms.RadioButton radio6;
        private System.Windows.Forms.RadioButton radio5;
        private System.Windows.Forms.RadioButton radio4;
        private System.Windows.Forms.RadioButton radio9;
        private System.Windows.Forms.RadioButton radio8;
        private System.Windows.Forms.RadioButton radio7;
        private System.Windows.Forms.TextBox txtOpacity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAngle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPadding;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtQuality;
        private System.Windows.Forms.Label label9;
    }
}