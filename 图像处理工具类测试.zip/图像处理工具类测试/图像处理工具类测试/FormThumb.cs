﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SDLight.Util;

namespace 图像处理工具类测试
{
    /// <summary>
    /// 演示如何生成高质量缩略图
    /// </summary>
    public partial class FormThumb : Form
    {        
        private FormMain fm;
        public FormThumb(FormMain fm)
        {
            InitializeComponent();
            this.fm = fm;
        }

        private void panel1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        }

        private void panel1_DragDrop(object sender, DragEventArgs e)
        {
            //实例化一个图像处理的工具类
            ImageTool iTool = new ImageTool();
            //获取参数
            var destWidth = int.Parse(txtDestWidth.Text);
            var destHeight = int.Parse(txtDestHeight.Text);
            var quality = int.Parse(txtQuality.Text);
            var error = string.Empty;
            //获取拖入的文件
            String[] files = e.Data.GetData(DataFormats.FileDrop, false) as String[];
            foreach (var file in files)
            {
                var fInfo = new FileInfo(file);
                if (fm.ImgExt.IndexOf(fInfo.Extension.ToLower()) == 0)
                {
                    continue;
                }
                //获取新名称
                string newFileName = fInfo.DirectoryName + "\\" + fInfo.Name.Replace(fInfo.Extension, "") + "_缩略图_" + destWidth + "x" + destHeight + fInfo.Extension;
                //直接调用生成缩略图的方法                
                iTool.GetThumbnailImage(newFileName, fInfo.FullName, destWidth, destHeight, quality, out error);
                if (!string.IsNullOrEmpty(error))
                {
                    MessageBox.Show(error);
                }
            }
        }
        private void FormThumb_Load(object sender, EventArgs e)
        {
            this.Top = fm.Top - this.Height;
            this.Left = fm.Left;
        }      
              
    }
}
