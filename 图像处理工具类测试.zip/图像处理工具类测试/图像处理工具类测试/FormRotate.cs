﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SDLight.Util;

namespace 图像处理工具类测试
{
    /// <summary>
    /// 演示Graphics绕矩形中心旋转的步骤和获取旋转图像
    /// </summary>
    public partial class FormRotate : Form
    {
        private FormMain fm;
        public FormRotate(FormMain fm)
        {
            InitializeComponent();
            this.fm = fm;
        }

        private void FormRotate_Load(object sender, EventArgs e)
        {            
            this.Left = fm.Left - this.Width + fm.Width;
            this.Top = fm.Top + fm.Height;
            this.tabControl1.SelectedIndex = 0;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //获取旋转后的图像
            if (this.tabControl1.SelectedIndex == 1)
            {
                this.pictureBox2.Image = Image.FromFile("water.jpg");
            }
            else
            {
                 
            }
        }
        #region Graphics绕某矩形绕中心旋转的步骤
        private void button3_Click(object sender, EventArgs e)
        {
            int angle = int.Parse(txtDestAngle.Text);//txtDestAngle为界面中一个TextBox控件
            var btn = sender as Button;
            Graphics graphics = null;
            try
            {
                //假设待处理的矩形 长宽为
                var w = 120;
                var h = 60;
                //创建graphics
                graphics = pictureBox1.CreateGraphics(); ;//pictureBox1为界面中一个PictureBox控件
                graphics.Clear(Color.Gray);
                //原始位置
                //画出矩形中心点
                graphics.DrawEllipse(new Pen(Color.Red), new Rectangle(w / 2 - 2, h / 2 - 2, 4, 4));
                //画出矩形当前位置
                graphics.DrawRectangle(new Pen(Color.Red), new Rectangle(0, 0, w, h));
                //***第一步***
                //将graphics坐标原点移到矩形中心点
                graphics.TranslateTransform(w / 2, h / 2);
                //画出矩形当前位置
                graphics.DrawRectangle(new Pen(Color.Yellow), new Rectangle(0, 0, w, h));
                //***第二步***
                //graphics旋转相应的角度(绕当前原点)
                graphics.RotateTransform(angle);
                //画出矩形当前位置
                graphics.DrawRectangle(new Pen(Color.Blue), new Rectangle(0, 0, w, h));
                //***每三步***
                //恢复graphics在水平和垂直方向的平移(沿当前原点)
                graphics.TranslateTransform(-w / 2, -h / 2);
                //画出矩形当前位置
                graphics.DrawRectangle(new Pen(Color.Green), new Rectangle(0, 0, w, h));
                //重至绘图的所有变换
                graphics.ResetTransform();
                graphics.Save();
                //***结束***
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (graphics != null)
                    graphics.Dispose();
            }
        }
        #endregion
        #region 获取旋转图像
        private void button1_Click(object sender, EventArgs e)
        {
            var angle = int.Parse(txtAngle.Text);
            ShowRotate(angle);             
        }
        /// <summary>
        /// 获取旋转后的图像并显示出来
        /// </summary>
        /// <param name="Angle"></param>
        private void ShowRotate(int Angle)
        {
            this.txtAngle.Text = Angle.ToString();
            var iTool = new ImageTool();
            Image srcImage = null;
            Image rotateImage = null;
            Graphics graphics = null;
            try
            {                
                srcImage = Image.FromFile("water.jpg");
                //调用方法获取旋转后的图像
                rotateImage = iTool.GetRotateImage(srcImage, Angle);
                graphics = pictureBox2.CreateGraphics();
                graphics.Clear(Color.Gray);
                //将旋转后的图像显示到pictureBox1里
                graphics.DrawImage(rotateImage, new Rectangle(0, 0, rotateImage.Width, rotateImage.Height));
                //是否显示图像所占矩形区域
                if (chkShowRotateRect.Checked)
                {
                    graphics.DrawRectangle(new Pen(Color.Yellow), new Rectangle(0, 0, rotateImage.Width, rotateImage.Height));
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (srcImage != null)
                    srcImage.Dispose();
                if (rotateImage != null)
                    rotateImage.Dispose();
                if (graphics != null)
                    graphics.Dispose();
            }             
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Angle = int.Parse(txtAngle.Text);
            var btn=sender as Button;
            if (btn.Text == "连续旋转")
            {
                timer1.Enabled = true;
                btn.Text = "停止";                
            }
            else
            {
                btn.Text = "连续旋转";
                timer1.Enabled = false;
            }            
        }
        static int Angle = 0;
        /// <summary>
        /// 定时器，连续旋转
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            ShowRotate(Angle);
            Angle += 10;
            if (Angle == 360) {               
                Angle = 0;
            }
                
        }
        #endregion

        
    }
}
