﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDLight.Util;
using System.IO;

namespace 图像处理工具类测试
{
    /// <summary>
    /// 演示如何给图片添加文字水印和图片水印
    /// </summary>
    public partial class FormWater : Form
    {
        private int position = 5;
        private FormMain fm;
        public FormWater(FormMain fm)
        {
            InitializeComponent();
            this.fm = fm;
        }

        private void FormWater_Load(object sender, EventArgs e)
        {
            this.Left = fm.Left - this.Width;
            this.Top = fm.Top - this.Height + fm.Height;
            
        }

        private void panel1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        }

        private void panel1_DragDrop(object sender, DragEventArgs e)
        {
            //实例化一个图像处理的工具类
            ImageTool iTool = new ImageTool();
            //获取参数
            var waterText = txtWaterText.Text.Trim();
            var waterImg = txtWaterImg.Text.Trim();
            var opacity = int.Parse(txtOpacity.Text);
            var padding = int.Parse(txtPadding.Text);
            var angle = int.Parse(txtAngle.Text);
            var quality = int.Parse(txtQuality.Text);          
            var error = string.Empty;
            //获取拖入的文件
            String[] files = e.Data.GetData(DataFormats.FileDrop, false) as String[];
            foreach (var file in files)
            {
                var fInfo = new FileInfo(file);
                if (fm.ImgExt.IndexOf(fInfo.Extension.ToLower()) == 0)
                {
                    continue;
                }
                //获取新名称
                string newFileName = fInfo.DirectoryName + "\\" + fInfo.Name.Replace(fInfo.Extension, "") + "_" + DateTime.Now.ToString("fff") + fInfo.Extension;
                //文字水印             
                iTool.DrawWaterText(newFileName, fInfo.FullName, waterText, null, new SolidBrush(Color.Black), position, padding, quality,opacity, out error);
                if (!string.IsNullOrEmpty(error))
                {
                    MessageBox.Show(error);
                }
                if (!string.IsNullOrEmpty(waterImg))
                {
                    //图片水印
                    iTool.DrawWaterImage(newFileName, newFileName, waterImg, position, padding, quality, opacity, angle, out error);
                    if (!string.IsNullOrEmpty(error))
                    {
                        MessageBox.Show(error);
                    }
                }
            }
        }

        private void radio1_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb.Checked == true)
            {
                string rbText = rb.Name.Replace("radio", "");
                position = int.Parse(rbText);
            }
        }       
    }
}
