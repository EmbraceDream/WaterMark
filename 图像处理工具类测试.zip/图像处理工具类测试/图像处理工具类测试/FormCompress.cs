﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDLight.Util;
using System.IO;

namespace 图像处理工具类测试
{
    /// <summary>
    /// 演示如何压缩和优化图片
    /// </summary>
    public partial class FormCompress : Form
    {        
        private FormMain fm;
        public FormCompress(FormMain fm)
        {
            InitializeComponent();
            this.fm = fm;
        }

        private void panel1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        }

        private void panel1_DragDrop(object sender, DragEventArgs e)
        {
            //实例化一个图像处理的工具类
            ImageTool iTool = new ImageTool();
            //获取参数
            var maxWidth = int.Parse(txtMaxWidth.Text);
            var maxHeight = int.Parse(txtMaxHeight.Text);
            var maxLength = int.Parse(txtMaxLength.Text);
            var quality = int.Parse(txtQuality.Text);
            var error = string.Empty;
            //获取拖入的文件
            String[] files = e.Data.GetData(DataFormats.FileDrop, false) as String[];
            foreach (var file in files)
            {
                var fInfo = new FileInfo(file);
                if (fm.ImgExt.IndexOf(fInfo.Extension.ToLower()) == 0)
                {
                    continue;
                }
                //获取新名称
                string newFileName = fInfo.DirectoryName + "\\" + fInfo.Name.Replace(fInfo.Extension, "") + "_限制宽高_" + maxWidth + "x" + maxHeight + fInfo.Extension;
                //调用限制宽高的图片压缩优化的方法             
                iTool.GetCompressImage(newFileName, fInfo.FullName, maxWidth, maxHeight, quality, out error);
                if (!string.IsNullOrEmpty(error))
                {
                    MessageBox.Show(error);
                }
                newFileName = fInfo.DirectoryName + "\\" + fInfo.Name.Replace(fInfo.Extension, "") + "_限制长边_" + maxLength + fInfo.Extension;
                //调用限制长度的图片压缩优化的方法  
                iTool.GetCompressImage(newFileName, fInfo.FullName,maxLength, quality, out error);
                if (!string.IsNullOrEmpty(error))
                {
                    MessageBox.Show(error);
                }
            }
        }

        private void FormCompress_Load(object sender, EventArgs e)
        {
            this.Left = fm.Left+fm.Width;
            this.Top = fm.Top;
        }

      
    }
}
